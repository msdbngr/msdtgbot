<?php
// تنظیمات پایه
define('BOT_TOKEN', 'mytoken');
define('DB_HOST', 'localhost');
define('DB_USER', 'blfusngm_masoudbbot_user');
define('DB_PASS', 'F&W__Z0aK9PF');
define('DB_NAME', 'blfusngm_masoudbbot_db');
?>